import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'in.gecp.campuscompass',
  appName: 'CampusCompass GECP',
  webDir: 'www',
  server: {
    url: 'https://YOUR-CAMPUSCOMPASS-DOMAIN.example',
    cleartext: false
  }
};

export default config;
