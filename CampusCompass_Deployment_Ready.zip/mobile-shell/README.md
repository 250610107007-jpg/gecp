# CampusCompass Android shell

The web app is already a PWA and can be installed directly on Android/Chrome and desktop.
For a Play Store APK/AAB, wrap the deployed HTTPS URL with Capacitor.

Required before building: a stable HTTPS deployment URL. Do not use localhost or an expiring Cloudflare tunnel for the Play Store build.

Example setup on a development machine:
```bash
npm create @capacitor/app@latest
# choose Android app, then configure the server URL in capacitor.config.ts
npx cap add android
npx cap open android
```

Use the deployed CampusCompass HTTPS URL as the app's server URL.
